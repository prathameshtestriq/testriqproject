<div class="card m-1" style="border-radius:15px">
	<div class="card-body custom_active" style="margin-bottom: -10px">
		<ul class="row dashboard-tab">
		
		  
		</ul>
	</div>
</div>

<?php /**PATH /var/www/html/RacesWebNew/resources/views/dashboard/tabs.blade.php ENDPATH**/ ?>